#!/bin/bash
btty=""
btty="/dev/tx$1"

printf "clock load:%s\n" $btty
while :
do
ittt=$(cat $btty)
printf "clock :%s signal: %s\n" $btty $ittt
if [ "$ittt" == "exit" ];
then 
break 
fi
date

printf "ready\n" > "/dev/tx0"

done

printf "exit clock: %s \n" $btty
printf "exit\n" > "/dev/tx0"













