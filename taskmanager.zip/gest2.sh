#!/bin/bash


ttty="ready"
ntty=""
printf "gest is in the mem\n"
for stti in {1..20..1}
do
ntty=/dev/tx$stti
printf "start clock %s\n" $ntty
bash "gest3.sh" "$stti" & 

done


while :
do

tti=0
ytty=""

for stti in {1..20..1}
do

ytty=/dev/tx$stti 
printf "send ready:%s\n" $ytty

printf "ready\n" > $ytty

tttti=$(cat /dev/tx0)
printf "tx0 recives:%s\n"  $tttti
if [ "$tttti" == "exit" ] ;
then 
break 
fi

done

if [ "$tttti" == "exit" ] ;
then 
break 
fi

done

for stti in {1..20..1}
do
ytty=/dev/tx$stti 
printf "exit:%s\n" $ytty
printf "exit\n" > $ytty
done











