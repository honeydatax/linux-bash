#!/bin/bash

printf "\033c"

sudo mkdir /mnt/ramdisk 2> /dev/null
sudo mount -t tmpfs -o size=8m tmpfs /mnt/ramdisk 2> /dev/null
sudo chmod 777 "/mnt/ramdisk" 2> /dev/null

ti="0"
tyy=""

for ti in {0..20..1}
do
ttyy=/dev/tx$ti
sudo mkfifo $ttyy 2> /dev/null
sudo chmod 777 $ttyy 2> /dev/null
dd if="$ttyy" iflag=nonblock of=/dev/null  2> /dev/null
done





bash gest2.sh & 




sleep 20
printf "exit\n" > "/dev/tx0"
exit




