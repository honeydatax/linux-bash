#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkAppChooser *app1;
void on_destroy();
void on_change();
void on_close();
int start_close=0;
int not_close=0;
int can_close=0;

void on_change(){
	const char *cc;
	char c[500];
	GAppInfo *apps;
	 if (start_close!=0) {
	 app1=GTK_APP_CHOOSER(window);
	 apps=gtk_app_chooser_get_app_info(app1);
	 cc=g_app_info_get_executable(apps);
	if (cc!=NULL){
		strcpy(c,cc);
		strcat(c," &");
		can_close=1;
		if (start_close!=0 && not_close==0) system (c);
		
	}
 }
	start_close=1;
}


void on_close(){
	printf("on_close\n");
	if (not_close==1) gtk_main_quit();
	
}




void on_destroy(){
	not_close=1;
	gtk_main_quit();
}


