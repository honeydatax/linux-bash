#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkWidget       *text1;

gpointer p;
guint gu1=1000;
int counter=0;
gint exitcode=0;
void on_destroy();
void on_clock();
time_t t;
struct tm tm;
gboolean on_clock(gpointer data);


gboolean on_clock(gpointer data){
  gchar entry_texts[500];
  gchar *entry_text;
  char c[500];
  t=time(NULL);
  tm=*localtime(&t);
  sprintf(c,"%d-%d-%d   %d:%d:%d",tm.tm_year +1900 ,tm.tm_mon +1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
  entry_text=&entry_texts[0];
  strcpy(entry_texts,c);
  gtk_entry_set_text (GTK_ENTRY (text1),entry_text);
  return TRUE;
 }

void on_destroy(){
	gtk_main_quit();
}











