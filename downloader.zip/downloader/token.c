#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void PrintList(char *argv);

void main(int argc, char *argv[]){
	char *argvs="(12+12)*3" ;
	printf("%s\n",argvs);
	PrintList(argvs);
	}

void PrintList(char *argv)

{
    int i;
    for (i = 0;i<strlen(argv); i++) {
        if (argv[i]=='+' || argv[i]=='-' || argv[i]=='*' || argv[i]=='/' || argv[i]=='\\' || argv[i]=='(' || argv[i]==')'){
			printf("\n%c\n", argv[i]);
		}else{
			printf("%c", argv[i]);}
		
    }
    printf("\n");

}

