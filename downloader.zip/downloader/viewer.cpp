#include "viewer.h"
int main(int argc, char *argv[])
{
	
    gtk_init(&argc, &argv);
	textss=&texts[0];
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "viewer.glade", NULL);

    window = GTK_WIDGET(gtk_builder_get_object(builder, "form1"));
    window2 = GTK_WIDGET(gtk_builder_get_object(builder, "form2"));
	entry2 = GTK_WIDGET(gtk_builder_get_object(builder, "text2"));
	button1 = GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
  
	g_signal_connect_swapped (window , "destroy",
			      G_CALLBACK (on_destroy),
			    window );
			     
	g_signal_connect_swapped (window , "selection-changed",
			      G_CALLBACK (on_select),
			    window ); 

	g_signal_connect_swapped (window2 , "show",
			      G_CALLBACK (on_acivate),
			    window );

	g_signal_connect_swapped (button1 , "clicked",
			      G_CALLBACK (on_close),
			    window );
	
   
    g_object_unref(builder);
    gtk_widget_show(window);                
    gtk_main();
    return 0;
}
