#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


//const char *printer="lpt:";
const char *printer="/dev/lp";
int firsttime=0;
GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window2;
GtkWidget       *window;
GtkFileChooser *file1;
void on_destroy();
void on_select();
void on_click();
void on_acivate();

void on_click(){
	gtk_widget_hide(window2);                
}


void on_acivate(){
	//gtk_widget_hide(button1);                
}


void on_select(){
	char *cc;
	char *dd;
	char c[600];
	char d[600];
	FILE *f1;
	FILE *f2;

	if (firsttime!=0){ 
		gtk_widget_show(window2);
	}
	file1=GTK_FILE_CHOOSER(window);
	cc=gtk_file_chooser_get_filename(file1);
	if (cc!=NULL){
		strcpy(c,cc);
		strcat(c,"");
		f1=fopen(c,"r");
		dd=&d[0];
		f2=fopen(printer,"w");
		printf("printing... %s\n",cc);
		do{
			fgets(dd,599,f1);
			fprintf(f2,"%s",dd);
		}while(!feof(f1));
		printf("end printing... %s\n",cc);
		fclose(f2);
		fclose(f1);
		
		

	}
	if (firsttime!=0) gtk_widget_show(button1);                
	firsttime=1;

}




void on_destroy(){
	gtk_main_quit();
}











