#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkFontChooser *font1;
void on_destroy();
void on_change();

void on_change(){
	char *cc;
	font1=GTK_FONT_CHOOSER(window);
	cc= gtk_font_chooser_get_font(font1);
	
	if (cc!=NULL){
			printf("%s\n",cc);
			gtk_main_quit();
	}

}






void on_destroy(){
	char *cc;
	font1=GTK_FONT_CHOOSER(window);
	cc= gtk_font_chooser_get_font(font1);
	
	if (cc!=NULL){
			printf("%s\n",cc);
	}
	gtk_main_quit();
}











