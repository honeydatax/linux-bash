#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

gpointer p;
int firsttime=0;
guint gu1=1000;
GtkWidget       *entry2;
GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window2;
GtkWidget       *window;
gint exitcode=0;
GtkFileChooser *file1;
char texts[68000];
char *textss;
void on_destroy();
void on_select();
void on_acivate();
gboolean on_clock(gpointer data);

gboolean on_clock(gpointer data){
	gtk_widget_set_size_request (GTK_WIDGET (entry2), 600,100 );
	gtk_widget_set_size_request (GTK_WIDGET (entry2), 600,320 );
	return FALSE;
}


void on_close(){
	gtk_widget_hide(window2);
}


void on_acivate(){
	gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(entry2)),texts,-1);
	strcpy(textss,"\0");
	exitcode=g_timeout_add(gu1,on_clock,NULL);
}


void on_select(){
	char *cc;
	char *dd;
	char c[600];
	char d[600];
	FILE *f1;
	
	file1=GTK_FILE_CHOOSER(window);
	cc=gtk_file_chooser_get_filename(file1);
	if (cc!=NULL){
		strcpy(c,cc);
		strcat(c,"");
		f1=fopen(c,"r");
		dd=&d[0];
		strcpy(textss,"\0");
		do{
			fgets(dd,599,f1);
			strcat(textss,dd);
		}while(!feof(f1));

		fclose(f1);
		
		

	}
	if (firsttime!=0){ 
		gtk_widget_show(window2);
	}

	firsttime=1;

}




void on_destroy(){
	gtk_main_quit();
}











