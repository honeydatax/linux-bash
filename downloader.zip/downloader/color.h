#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkColorChooser *color1;
void on_destroy();
void on_change();

void on_change(){
	char *cc;
	GdkRGBA colors;
	double reds;
	double greens;
	double blues;
	double alphas;
	color1=GTK_COLOR_CHOOSER(window);
	gtk_color_chooser_get_rgba(color1,&colors);
	
	
	
		reds=(double) colors.red;
		greens=(double) colors.green;
		blues=(double) colors.blue;
		alphas=(double) colors.alpha;
		printf("r=%f,g=%f,b=%f,a=%f,\n",reds,greens,blues,alphas);
	

	//gtk_main_quit();
}






void on_destroy(){
	char *cc;
	GdkRGBA colors;
	double reds;
	double greens;
	double blues;
	double alphas;
	color1=GTK_COLOR_CHOOSER(window);
	gtk_color_chooser_get_rgba(color1,&colors);
	
	
	
		reds=(double) colors.red;
		greens=(double) colors.green;
		blues=(double) colors.blue;
		alphas=(double) colors.alpha;
		printf("r=%f,g=%f,b=%f,a=%f,\n",reds,greens,blues,alphas);
	
	
	gtk_main_quit();
}











