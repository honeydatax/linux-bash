#include "code.h"
int main(int argc, char *argv[])
{
	
    gtk_init(&argc, &argv);
	textss=&texts[0];
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "code.glade", NULL);

    window = GTK_WIDGET(gtk_builder_get_object(builder, "form1"));
    window2 = GTK_WIDGET(gtk_builder_get_object(builder, "form2"));
	button1 = GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
	tree1 = GTK_WIDGET(gtk_builder_get_object(builder, "tree1"));
	store=gtk_list_store_new(1,G_TYPE_STRING);
	render=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree1),-1,"Name",render,"text",0,NULL);
	model=GTK_TREE_MODEL(store);
	gtk_tree_view_set_model(GTK_TREE_VIEW(tree1),model);
  
	g_signal_connect_swapped (window , "destroy",
			      G_CALLBACK (on_destroy),
			    window );
			     
	g_signal_connect_swapped (window , "selection-changed",
			      G_CALLBACK (on_select),
			    window ); 

	g_signal_connect_swapped (window2 , "show",
			      G_CALLBACK (on_acivate),
			    window );

	g_signal_connect_swapped (button1 , "clicked",
			      G_CALLBACK (on_close),
			    window );
	
   
    g_object_unref(builder);
    gtk_widget_show(window);                
    gtk_main();
    return 0;
}
