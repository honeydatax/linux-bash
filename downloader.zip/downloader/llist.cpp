#include "llist.h"
int main(int argc, char *argv[])
{
	
    gtk_init(&argc, &argv);
	textss=&texts[0];
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "llist.glade", NULL);

    window = GTK_WIDGET(gtk_builder_get_object(builder, "form1"));
	tree1 = GTK_WIDGET(gtk_builder_get_object(builder, "tree1"));
	tree2 = GTK_WIDGET(gtk_builder_get_object(builder, "tree2"));
	store=gtk_list_store_new(1,G_TYPE_STRING);
	store1=gtk_list_store_new(1,G_TYPE_STRING);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"8086",-1);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"80186",-1);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"80286",-1);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"80386",-1);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"80486",-1);
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,0,"80586",-1);
	render=gtk_cell_renderer_text_new();
	render1=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree1),-1,"list1",render,"text",0,NULL);
	gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW(tree2),-1,"list2",render1,"text",0,NULL);
	model=GTK_TREE_MODEL(store);
	model1=GTK_TREE_MODEL(store1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(tree1),model);
	gtk_tree_view_set_model(GTK_TREE_VIEW(tree2),model1);
  
	g_signal_connect_swapped (window , "destroy",
			      G_CALLBACK (on_destroy),
			    window );

	g_signal_connect_swapped (tree1, "row-activated",
			      G_CALLBACK (on_delete1),
			    NULL );

  g_signal_connect_swapped (tree2, "row-activated",
			      G_CALLBACK (on_delete2),
			    NULL );

    g_object_unref(builder);
    gtk_widget_show(window);                
    gtk_main();
    return 0;
}
