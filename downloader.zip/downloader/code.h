#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

gpointer p;
int firsttime=0;
guint gu1=3000;
GtkWidget       *tree1;
GtkWidget       *entry2;
GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window2;
GtkWidget       *window;
GtkCellRenderer *render;
GtkTreeModel *model;
GtkListStore *store;
GtkTreeIter iter;
char *cc;
char *dd;
char c[600];
char d[600];
FILE *f1;
gint exitcode=0;
GtkFileChooser *file1;
char texts[68000];
char *textss;
void on_destroy();
void on_select();
void on_acivate();
gboolean on_clock(gpointer data);

gboolean on_clock(gpointer data){
	//gtk_widget_set_size_request (GTK_WIDGET (window2), 600,320 );
	return FALSE;
}


void on_close(){
	gtk_widget_hide(window2);
}


void on_acivate(){
	if (cc!=NULL){
		gtk_list_store_clear(store);
		strcpy(c,cc);
		strcat(c,"");
		f1=fopen(c,"r");
		dd=&d[0];
		strcpy(textss,"\0");
		do{
			fgets(dd,599,f1);
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,0,dd,-1);

			
		}while(!feof(f1));

	}
	
	//gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_SOURCE_VIEW(entry2)),texts,-1);
	exitcode=g_timeout_add(gu1,on_clock,NULL);

}


void on_select(){
	
	file1=GTK_FILE_CHOOSER(window);
	cc=gtk_file_chooser_get_filename(file1);
	if (firsttime!=0){ 
		gtk_widget_show(window2);
	}

	firsttime=1;

}




void on_destroy(){
	gtk_main_quit();
}











