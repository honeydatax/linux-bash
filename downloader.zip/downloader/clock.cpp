#include "clock.h"
int main(int argc, char *argv[])
{
	
    gtk_init(&argc, &argv);

    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "clock.glade", NULL);

    window = GTK_WIDGET(gtk_builder_get_object(builder, "form1"));
    text1 = GTK_WIDGET(gtk_builder_get_object(builder, "text1"));
  
	g_signal_connect_swapped (window , "destroy",
			      G_CALLBACK (on_destroy),
			    window );
	
   
    g_object_unref(builder);
    gtk_widget_show(window); 
    exitcode=g_timeout_add(gu1,on_clock,NULL);
    gtk_main();
    g_source_remove(exitcode);
    
    return 0;
}
