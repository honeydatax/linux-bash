#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

gpointer p;
int firsttime=0;
guint gu1=3000;
GtkTreeSelection  *selected;
GtkTreeSelection  *selected1;
GtkWidget       *tree1;
GtkWidget       *tree2;
GtkWidget       *button1;
GtkWidget       *button2;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkCellRenderer *render1;
GtkTreeModel *model1;
GtkListStore *store1;
GtkTreeIter iter1;
GtkCellRenderer *render;
GtkTreeModel *model;
GtkListStore *store;
GtkTreeIter iter;
int counter1=0;
int counter2=0;
char *cc;
char *dd;
char c[600];
char d[600];
FILE *f1;
gint exitcode=0;
GtkFileChooser *file1;
char texts[68000];
char *textss;
void on_destroy();
void on_select();
void on_acivate();
void on_delete1(GtkTreeView *view,GtkTreePath *paths,GtkTreeViewColumn *Column,gpointer userdatas);
void on_delete2(GtkTreeView *view,GtkTreePath *paths,GtkTreeViewColumn *Column,gpointer userdatas);

void on_delete1(GtkTreeView *view,GtkTreePath *paths,GtkTreeViewColumn *Column,gpointer userdatas){
	gchar *name;
	GtkTreeModel *mmodel;
	GtkTreeIter iters1;
	mmodel=gtk_tree_view_get_model(GTK_TREE_VIEW(tree1));
			if(!gtk_tree_model_get_iter(mmodel,&iters1,paths)) return;
				if(gtk_tree_model_get_iter(mmodel,&iters1,paths)){
					gtk_tree_model_get(mmodel,&iters1,0,&name,-1);
					gtk_list_store_append(store1,&iter1);
					gtk_list_store_set(store1,&iter1,0,name,-1);
				}

			gtk_list_store_remove(GTK_LIST_STORE(mmodel),&iters1);
}

void on_delete2(GtkTreeView *view,GtkTreePath *paths,GtkTreeViewColumn *Column,gpointer userdatas){
	gchar *name;
	GtkTreeModel *mmodel;
	GtkTreeIter iters1;
	mmodel=gtk_tree_view_get_model(GTK_TREE_VIEW(tree2));
			if(!gtk_tree_model_get_iter(mmodel,&iters1,paths)) return;
				if(gtk_tree_model_get_iter(mmodel,&iters1,paths)){
					gtk_tree_model_get(mmodel,&iters1,0,&name,-1);
					gtk_list_store_append(store,&iter);
					gtk_list_store_set(store,&iter,0,name,-1);
				}

			gtk_list_store_remove(GTK_LIST_STORE(mmodel),&iters1);

}



void on_destroy(){
	gtk_main_quit();
}











