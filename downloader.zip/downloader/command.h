#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GtkWidget       *button1;
GtkBuilder      *builder; 
GtkWidget       *window;
GtkWidget       *text1;

void on_destroy();
void on_click();


void on_click(){
  const gchar *entry_text;
  char c[500];
  entry_text = gtk_entry_get_text (GTK_ENTRY (text1));
  strcpy(c,entry_text);
  strcat(c," &");
  system(entry_text);
  
}

void on_destroy(){
	gtk_main_quit();
}











